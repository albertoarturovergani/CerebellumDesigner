#!/usr/bin/env bash
set -euo pipefail
cd_install_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$cd_install_dir"
if (( EUID == 0 )); then
    echo "Run as your normal Ubuntu user, not with sudo. Only apt requests sudo." >&2
    exit 1
fi
source /etc/os-release
if [[ "$ID" != ubuntu || "$VERSION_ID" != 24.04 ]]; then
    echo "This installer targets Ubuntu 24.04 LTS with Python 3.12." >&2
    exit 1
fi
python3 -c 'import sys; assert sys.version_info[:2] == (3,12), "Python 3.12 required"'
unset PYTHONPATH PYTHONHOME
export PYTHONNOUSERSITE=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
sudo apt-get update
sudo apt-get install -y python3-venv python3-dev python3-pip build-essential pkg-config \
    libopenmpi-dev openmpi-bin git fonts-dejavu-core libhdf5-dev libspatialindex-dev
python3 verify_kit.py
if [[ ! -e szpaper2 ]]; then
    python3 -m venv szpaper2
elif [[ ! -f szpaper2/pyvenv.cfg ]]; then
    echo "szpaper2 exists but is not a virtual environment; nothing overwritten." >&2
    exit 1
fi
source "$cd_install_dir/activate.sh"
python -m pip install --upgrade pip setuptools wheel
python -m pip install -r requirements-designer.txt -c constraints-ubuntu24.04.txt \
    -e ./src/cerebellar-models -e ./DeformationAlgorithm
python -m pip check
python check_install.py
python -m pip freeze > installed-versions.txt
if (( $(nproc) >= 8 )); then
    mpirun -n 8 python mpi_smoke.py
else
    echo "Designer is installed. Only $(nproc) CPUs are visible; assign 8 vCPUs before MPI-8 reconstruction."
fi
echo "Installation complete. Start with: bash start_designer.sh"
