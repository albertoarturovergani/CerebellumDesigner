Unipolar Brush Cells
~~~~~~~~~~~~~~~~~~~~

Unipolar Brush cells (UBC) are excitatory interneurons located in the granular layer that acts as relay cells for
glomerulus [#mugnaini_2011]_. The default configuration for UBCs is implemented in
`ubc.yaml <https://github.com/dbbs-lab/cerebellar-models/blob/master/configurations/mouse/cell_types/ubc.yaml>`_.

Cellular density
^^^^^^^^^^^^^^^^

The density of UBC depends on the cerebellar cortex regions. Sekerková et al. (2014) [#sekerkova_2014]_ have reported
the following densities for mouse brain:

.. csv-table::
   :header-rows: 1
   :delim: ;

    Brain region name; Density (:math:`mm^{-3}`)
    Lingula (I); 6000
    Lobule II; 6000
    Central Lobule; 6000
    Culmen; 6000
    Declive (VI); 6000
    Folium-tuber vermis (VII); 6000
    Pyramus (VIII); 6000
    Uvula (IX); 25600
    Nodulus (X); 98400
    Simple lobule; 6000
    Ansiform lobule; 6000
    Paramedian lobule; 25600
    Copula pyramidis; 25600
    Flocculus; 78000

Remember that these values need to be converted into cell / :math:`\mu m^{-3}` to be used in BSB configurations.

Connectivity
^^^^^^^^^^^^

UBC are here represented with one dendrite (max. ``50`` :math:`\mu m` long), that connects to a single glomerulus and
produces ``4`` axons (max. ``500`` :math:`\mu m` long), each having one UBC glomerulus terminals.

.. note::
   UBC cells can have more than one dendrite but this subpopulation is not represented in the current circuit.
   It is also unclear if only a single UBC can connect to a glomerulus so this constraint is at the moment not
   implemented in the provided configurations.

Mf and UBC based glomeruli act similarly in the network: GrC, GoC and UBC can connect to them simultaneously.
UBC are also inhibited by Golgi cells that sends axons to their presynaptic glomerulus. One third of the UBC population
is reported to receive input from mf glomerulus while the rest receives input from UBC glomerulus. See review of
Mugnaini et al. (2011) [#mugnaini_2011]_ for more information. The connection id of the first column corresponds to
the numbers reported in :numref:`fig-network` and overrides the table :ref:`table-connectivity` of the canonical circuit.

.. csv-table::
   :header-rows: 1
   :delim: ;

   #; Source Name; Source Branch; Target Name; Target Branch; Strategy; References
   2; glom & ubc_glon ; /; GrC; dendrites; :ref:`glom_grc`; Houston et al. (2017) [#houston_2017]_
   3; glom & ubc_glon; /; GoC; basal dendrites; :ref:`glom_goc`; Kanichay and Silver (2008) [#kanichay_2008]_
   16; UBC ; /; ubc_glom ; /; :ref:`ubc_glom`; Mugnaini et al. (2011) [#mugnaini_2011]_
   17; glom & ubc_glon ; /; UBC ; /; :ref:`glom_ubc`; Mugnaini et al. (2011) [#mugnaini_2011]_
   18; Golgi ; axon; UBC ; /; :ref:`goc_glom`; Mugnaini et al. (2011) [#mugnaini_2011]_

References
^^^^^^^^^^

.. [#mugnaini_2011] Mugnaini, E., Sekerková, G., & Martina, M. (2011).
   "The unipolar brush cell: a remarkable neuron finally receiving deserved attention."
   Brain research reviews, 66(1-2), 220-245.
   https://doi.org/10.1016/j.brainresrev.2010.10.001
.. [#sekerkova_2014] Sekerková, G., Watanabe, M., Martina, M., & Mugnaini, E. (2014).
   "Differential distribution of phospholipase C beta isoforms and diaglycerol kinase-beta in rodents cerebella
   corroborates the division of unipolar brush cells into two major subtypes."
   Brain Structure and Function, 219, 719-749.
   https://doi.org/10.1007/s00429-013-0531-9
.. [#houston_2017] Houston, C. M., Diamanti, E., Diamantaki, M., Kutsarova, E., Cook, A., Sultan, F.,
   & Brickley, S. G. (2017).
   "Exploring the significance of morphological diversity for cerebellar granule cell excitability."
   Scientific Reports, 7(1), 1-16.
   https://doi.org/10.1038/srep46147
.. [#kanichay_2008] Kanichay, R. T., & Silver, R. A. (2008).
   "Synaptic and cellular properties of the feedforward inhibitory circuit within the input layer of the cerebellar cortex."
   Journal of Neuroscience, 28(36), 8955-8967.
   https://doi.org/10.1523/JNEUROSCI.5469-07.2008
