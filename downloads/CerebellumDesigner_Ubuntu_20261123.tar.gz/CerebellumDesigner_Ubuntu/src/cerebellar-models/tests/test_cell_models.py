import os
import unittest
from os.path import abspath, dirname, getmtime, isfile, join

import nest
import numpy as np
from bsb import Scaffold, iter_recordings, parse_configuration_content
from bsb.services import MPI
from bsb_test import NumpyTestCase, RandomStorageFixture
from pynestml.exceptions.invalid_path_exception import InvalidPathException
from scipy.optimize import curve_fit


class TestNestModuleLoading(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        ROOT_FOLDER = abspath(dirname(dirname(__file__)))
        os.chdir(ROOT_FOLDER)

    def test_build_models(self):
        from cerebellar_models.nest_models.build_models import (
            _build_nest_models,
            _nest_prefix,
        )

        # cerebmodule should have been built
        cerebmodule_file = join(_nest_prefix(), "lib/nest/cerebmodule.so")
        self.assertTrue(isfile(cerebmodule_file))
        # Does not raise because module exists
        _build_nest_models(model_dir="bla")
        old_mtime = getmtime(cerebmodule_file)
        _build_nest_models(redo=True)  # Force update
        self.assertTrue(getmtime(cerebmodule_file) > old_mtime, "module should be updated")
        os.remove(cerebmodule_file)
        with self.assertRaises(OSError):
            _build_nest_models(model_dir="bla")
        with self.assertRaises(InvalidPathException):
            _build_nest_models(model_dir=dirname(abspath(__file__)))


@unittest.skipIf(MPI.get_size() > 1, "Skipped during parallel testing.")
class TestSingleCellModels(
    RandomStorageFixture, NumpyTestCase, unittest.TestCase, engine_name="hdf5"
):
    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        ROOT_FOLDER = abspath(dirname(dirname(__file__)))
        os.chdir(ROOT_FOLDER)

    def setUp(self):
        super().setUp()
        self.conf_basal_exp = "../configurations/mouse/in-vitro/nest/basal_vitro.yaml"
        self.configuration_dict = {
            "name": "test",
            "storage": {"engine": "hdf5"},
            "rng": {"seed": 1234},
            "network": {"x": 1, "y": 1, "z": 1},
            "components": ["cerebellar_models/nest_models/build_models.py"],
            "partitions": {"B": {"type": "layer", "thickness": 1}},
            "cell_types": {
                "granule_cell": {"spatial": {"radius": 1, "count": 10}},
                "golgi_cell": {"spatial": {"radius": 1, "count": 10}},
                "purkinje_cell": {"spatial": {"radius": 1, "count": 10}},
                "purkinje_awake_cell": {"spatial": {"radius": 1, "count": 10}},
                "basket_cell": {"spatial": {"radius": 1, "count": 10}},
                "stellate_cell": {"spatial": {"radius": 1, "count": 10}},
                "unipolar_brush_cell": {"spatial": {"radius": 1, "count": 10}},
                "dcn_p_cell": {"spatial": {"radius": 1, "count": 10}},
                "dcn_p_awake_cell": {"spatial": {"radius": 1, "count": 10}},
                "dcn_i_cell": {"spatial": {"radius": 1, "count": 10}},
                "dcn_i_awake_cell": {"spatial": {"radius": 1, "count": 10}},
            },
            "placement": {
                "placement_A": {
                    "strategy": "bsb.placement.strategy.FixedPositions",
                    "cell_types": [
                        "granule_cell",
                        "golgi_cell",
                        "purkinje_cell",
                        "purkinje_awake_cell",
                        "basket_cell",
                        "stellate_cell",
                        "unipolar_brush_cell",
                        "dcn_p_cell",
                        "dcn_p_awake_cell",
                        "dcn_i_cell",
                        "dcn_i_awake_cell",
                    ],
                    "partitions": ["B"],
                    "positions": [[1, 1, 1]] * 10,
                }
            },
            "connectivity": {},
        }

    @staticmethod
    def _load_spike_data(results):
        cell_dict = {}
        # BSB 8 multiplexes all the cells of a recorder in one SpikeTrain;
        # iter_recordings splits it back into one recording per cell.
        for recording in iter_recordings(results.block, kind="cell"):
            if not recording.is_spike_train:
                continue
            cell_type = recording.device.split("_rec")[0]
            if cell_type not in cell_dict:
                cell_dict[cell_type] = {}
            # Silent cells are part of the recorder's roster but have no spike to analyze.
            if len(recording.signal) > 0:
                cell_id = str(recording.annotations["bsb_cell_id"])
                cell_dict[cell_type][cell_id] = list(recording.signal.magnitude)
        return cell_dict

    @staticmethod
    def _f_linear(x, m, q):
        """
        Linear function to fit fI curves.
        """
        return m * x + q

    @staticmethod
    def _fit_lin(x, y):
        params, covariance = curve_fit(TestSingleCellModels._f_linear, x, y)
        m, q = params
        m_std, q_std = np.sqrt(np.diag(covariance))
        return m, m_std, q, q_std

    @staticmethod
    def _compute_firing_rate(spikes, start=0, stop=10000, first_two=False):
        isis = [
            np.diff(
                np.array(spike_time)[
                    (np.array(spike_time) >= start) * (np.array(spike_time) < stop)
                ]
            )
            for spike_time in spikes
        ]

        if first_two:
            isis = np.array([isi[0] for isi in isis])
        else:
            isis = np.array([np.mean(isi) for isi in isis if len(isi) > 0])
        f_tonic = (1.0 / isis / 0.001) if len(isis) > 0 else 0.0  # in Hz
        return np.mean(f_tonic), np.std(f_tonic)

    def test_fi_curves_geminiani(self):
        conf_cell_vitro = (
            "../configurations/mouse/in-vitro/nest/cell_models/eglif_cond_alpha_multisyn.yaml"
        )
        conf_cell_awake = (
            "../configurations/mouse/awake/nest/cell_models/eglif_cond_alpha_multisyn.yaml"
        )
        config_dict = self.configuration_dict.copy()
        config_dict["simulations"] = {
            "test": {
                "simulator": "nest",
                "duration": 21001,
                "resolution": 0.1,
                "modules": ["cerebmodule"],
                "cell_models": {
                    "$import": {
                        "ref": conf_cell_vitro + "#/cell_models",
                        "values": [
                            "granule_cell",
                            "golgi_cell",
                            "purkinje_cell",
                            "basket_cell",
                            "stellate_cell",
                            "unipolar_brush_cell",
                        ],
                    },
                    "purkinje_awake_cell": {
                        "$import": {
                            "ref": conf_cell_awake + "#/cell_models/purkinje_cell",
                            "values": ["constants", "model"],
                        }
                    },
                    "dcn_p_cell": {
                        "$import": {
                            "ref": conf_cell_vitro + "#/cell_models/dcn_p",
                            "values": ["constants", "model"],
                        }
                    },
                    "dcn_p_awake_cell": {
                        "$import": {
                            "ref": conf_cell_awake + "#/cell_models/dcn_p",
                            "values": ["constants", "model"],
                        }
                    },
                    "dcn_i_cell": {
                        "$import": {
                            "ref": conf_cell_vitro + "#/cell_models/dcn_i",
                            "values": ["constants", "model"],
                        }
                    },
                    "dcn_i_awake_cell": {
                        "$import": {
                            "ref": conf_cell_awake + "#/cell_models/dcn_i",
                            "values": ["constants", "model"],
                        }
                    },
                },
                "connection_models": {},
                "devices": {
                    "$import": {
                        "ref": self.conf_basal_exp + "#/simulations/basal_activity/devices",
                        "values": [
                            "granule_record",
                            "golgi_record",
                            "purkinje_record",
                            "basket_record",
                            "stellate_record",
                            "unipolar_brush_record",
                        ],
                    },
                    "purkinje_awake_record": {
                        "device": "spike_recorder",
                        "delay": 0.1,
                        "targetting": {
                            "strategy": "cell_model",
                            "cell_models": ["purkinje_awake_cell"],
                        },
                    },
                    "dcn_p_record": {
                        "device": "spike_recorder",
                        "delay": 0.1,
                        "targetting": {"strategy": "cell_model", "cell_models": ["dcn_p_cell"]},
                    },
                    "dcn_p_awake_record": {
                        "device": "spike_recorder",
                        "delay": 0.1,
                        "targetting": {
                            "strategy": "cell_model",
                            "cell_models": ["dcn_p_awake_cell"],
                        },
                    },
                    "dcn_i_record": {
                        "device": "spike_recorder",
                        "delay": 0.1,
                        "targetting": {"strategy": "cell_model", "cell_models": ["dcn_i_cell"]},
                    },
                    "dcn_i_awake_record": {
                        "device": "spike_recorder",
                        "delay": 0.1,
                        "targetting": {
                            "strategy": "cell_model",
                            "cell_models": ["dcn_i_awake_cell"],
                        },
                    },
                },
            }
        }
        protocol = {
            "golgi": {
                "amplitudes": [100, 200, 300, 400, 500, 600],
                "starts": [10, 12, 14, 16, 18, 20],
                "stops": [11, 13, 15, 17, 19, 21],
            },
            "granule": {
                "amplitudes": [16, 20, 24],
                "starts": [10, 12, 14],
                "stops": [11, 13, 15],
            },
            "purkinje": {
                "amplitudes": [500, 1000, 2400],
                "starts": [10, 12, 14],
                "stops": [11, 13, 14.01],
            },
            "purkinje_awake": {
                "amplitudes": [500, 1000, 2400],
                "starts": [10, 12, 14],
                "stops": [11, 13, 14.01],
            },
            "basket": {
                "amplitudes": [12, 24, 36],
                "starts": [10, 12, 14],
                "stops": [11, 13, 15],
            },
            "stellate": {
                "amplitudes": [12, 24, 36],
                "starts": [10, 12, 14],
                "stops": [11, 13, 15],
            },
            "unipolar_brush": {
                "amplitudes": [12, 24, 36],
                "starts": [10, 12, 14],
                "stops": [11, 13, 15],
            },
            "dcn_p": {
                "amplitudes": [142, 284, 426],
                "starts": [10, 12, 14],
                "stops": [11, 13, 15],
            },
            "dcn_p_awake": {
                "amplitudes": [142, 284, 426],
                "starts": [10, 12, 14],
                "stops": [11, 13, 15],
            },
            "dcn_i": {
                "amplitudes": [56, 112, 168],
                "starts": [10, 12, 14],
                "stops": [11, 13, 15],
            },
            "dcn_i_awake": {
                "amplitudes": [56, 112, 168],
                "starts": [10, 12, 14],
                "stops": [11, 13, 15],
            },
        }
        predicted = {
            "golgi": {"autorhythm": 12.8, "slope": 0.2},
            "granule": {"autorhythm": 0.0, "slope": 3.70},
            "purkinje": {"autorhythm": 45.6, "slope": 0.08},
            "purkinje_awake": {
                "autorhythm": 83.2,
                "slope": 0.095,
            },  # to match Geminiani et al. 2024
            "basket": {"autorhythm": 9.51, "slope": 2.16},
            "stellate": {"autorhythm": 9.51, "slope": 2.16},
            "unipolar_brush": {"autorhythm": 0.0, "slope": 2.35},  # no source available
            "dcn_p": {"autorhythm": 32.9, "slope": 0.28},  # f tonic slightly increased (+~1.4Hz)
            "dcn_i": {"autorhythm": 14.1, "slope": 0.4},  # f tonic slightly decreased (-~0.3Hz)
            "dcn_p_awake": {"autorhythm": 61.78, "slope": 0.256},  # to match Geminiani et al. 2024
            "dcn_i_awake": {"autorhythm": 14.11, "slope": 0.44},  # to match Geminiani et al. 2024
        }
        for cell_type in predicted:
            for i, stim in enumerate(protocol[cell_type]["amplitudes"]):
                config_dict["simulations"]["test"]["devices"][f"stimulus_{cell_type}_{i}"] = {
                    "device": "dc_generator",
                    "amplitude": stim,
                    "start": protocol[cell_type]["starts"][i] * 1e3,
                    "stop": protocol[cell_type]["stops"][i] * 1e3,
                    "targetting": {"strategy": "cell_model", "cell_models": [f"{cell_type}_cell"]},
                    "weight": 1.0,
                    "delay": 0.1,
                }
        cfg = parse_configuration_content(
            config_dict, parser="json", path=os.path.realpath(__file__)
        )
        network = Scaffold(cfg, self.storage)
        network.compile()
        results = network.run_simulation("test")
        cell_dict = self._load_spike_data(results)
        for cell_type in predicted:
            spike_dict = cell_dict[cell_type]
            # Test autorhythm
            f_tonic, std_tonic = self._compute_firing_rate(spike_dict.values(), start=0, stop=10000)
            std_tonic = max(std_tonic, 0.01)  # in case std is too small
            self.assertTrue(
                abs(predicted[cell_type]["autorhythm"] - f_tonic) <= 2 * std_tonic,
                f"{cell_type}: {f_tonic} Hz",
            )

            # Test F/i curve points
            starts = protocol[cell_type]["starts"]
            f_points = np.zeros(len(starts))
            i_points = np.zeros(len(starts))
            for i, start in enumerate(starts):
                f_tonic, std_tonic = self._compute_firing_rate(
                    spike_dict.values(),
                    start=start * 1e3,
                    stop=protocol[cell_type]["stops"][i] * 1e3,
                    first_two=True,
                )
                f_points[i] = f_tonic
                i_points[i] = protocol[cell_type]["amplitudes"][i]
            slope, slope_std, offset, offset_std = self._fit_lin(i_points[1:], f_points[1:])
            self.assertTrue(
                abs(slope - predicted[cell_type]["slope"]) <= 2 * slope_std,
                f"{cell_type} slope: {slope}, predicted {predicted[cell_type]['slope']}",
            )

    def test_fi_curve_degrazia(self):
        conf_cell_vitro = "../configurations/mouse/in-vitro/nest/cell_models/eglif_multirec.yaml"
        config_dict = self.configuration_dict.copy()
        config_dict["simulations"] = {
            "test": {
                "simulator": "nest",
                "duration": 2000.1,
                "resolution": 0.1,
                "modules": ["cerebmodule"],
                "cell_models": {
                    "granule_cell": {"constants": {"V_m": -62}},
                    "golgi_cell": {"constants": {"V_m": -62}},
                    "purkinje_cell": {"constants": {"V_m": -59}},
                    "basket_cell": {"constants": {"V_m": -68}},
                    "stellate_cell": {"constants": {"V_m": -68}},
                    "$import": {
                        "ref": conf_cell_vitro + "#/cell_models",
                        "values": [
                            "granule_cell",
                            "golgi_cell",
                            "purkinje_cell",
                            "basket_cell",
                            "stellate_cell",
                        ],
                    },
                },
                "connection_models": {},
                "devices": {
                    "$import": {
                        "ref": self.conf_basal_exp + "#/simulations/basal_activity/devices",
                        "values": [
                            "granule_record",
                            "golgi_record",
                            "purkinje_record",
                            "basket_record",
                            "stellate_record",
                        ],
                    },
                },
            }
        }
        # values from De Grazia 2026
        predicted = {
            "golgi": {"autorhythm": 12.48, "start": 200, "end": 700.0},
            "granule": {"autorhythm": 0.0, "start": 100, "end": 600.0},
            "purkinje": {"autorhythm": 35.74, "start": 200, "end": 700.0},
            "basket": {"autorhythm": 14.64, "start": 500, "end": 1500.0},
            "stellate": {"autorhythm": 21.87, "start": 200, "end": 700.0},
        }
        cfg = parse_configuration_content(
            config_dict, parser="json", path=os.path.realpath(__file__)
        )
        network = Scaffold(cfg, self.storage)
        network.compile()
        results = network.run_simulation("test")
        cell_dict = self._load_spike_data(results)
        for cell_type in predicted:
            spike_dict = cell_dict[cell_type]
            # Test autorhythm
            # since there is no stochasticity, we can take the results of the first cell.
            prediction = predicted[cell_type]
            if len(spike_dict) == 0:
                f_tonic = 0.0
            else:
                spike_times = np.array(list(spike_dict.values())[0])
                spike_times = spike_times[
                    (spike_times > prediction["start"]) * (spike_times < prediction["end"])
                ]
                duration = spike_times[-1] - prediction["start"]
                f_tonic = len(spike_times) / duration * 1000.0
            self.assertTrue(
                abs(prediction["autorhythm"] - f_tonic) <= 0.01,
                f"{cell_type}: {f_tonic} Hz, predicted {prediction['autorhythm']}",
            )
