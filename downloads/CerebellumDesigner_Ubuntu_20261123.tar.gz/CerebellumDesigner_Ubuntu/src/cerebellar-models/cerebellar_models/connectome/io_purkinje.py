"""
Module for the configuration node of the IO to purkinje cells AfterConnectivityHook
"""

import numpy as np
from bsb import AfterConnectivityHook, ConnectionStrategy, config, refs, types


@config.node
class DuplicateSynapses(AfterConnectivityHook):
    """
    BSB postprocessing to duplicate connections from a connection strategy into
    multiple synapses per pair.
    """

    conn_strategy: ConnectionStrategy = config.ref(refs.connectivity_ref, required=True)
    """Connection Strategy to on which to apply the postprocessing."""

    contacts = config.attr(type=types.distribution(), default=1)
    """Number or distribution determining the amount of synaptic contacts one cell will form on another"""

    def postprocess(self):
        for cs_name in self.conn_strategy.get_output_names():
            # Draw the number of connection to create
            cs = self.scaffold.get_connectivity_set(cs_name)
            pre_ps = cs.pre_type.get_placement_set()
            post_ps = cs.post_type.get_placement_set()
            # Keyed on the hook and the connectivity set, so the draw is reproducible
            # and does not depend on which rank computes it.
            rng = self.get_rng(key=("after_connectivity", self.name, cs_name))
            duplicates = np.asarray(self.contacts.draw(len(cs), rng=rng), dtype=int)
            for (pre_locs, post_locs), n in zip(cs.load_connections(), duplicates):
                if n > 1:
                    pre_locs = np.repeat([pre_locs], n - 1, axis=0)
                    post_locs = np.repeat([post_locs], n - 1, axis=0)
                    cs.connect(pre_ps, post_ps, pre_locs, post_locs)
