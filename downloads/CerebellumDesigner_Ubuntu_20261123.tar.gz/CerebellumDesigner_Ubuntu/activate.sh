#!/usr/bin/env bash
# Source this file from Bash. All paths are computed from this extracted folder.
cd_project_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
if [[ ! -f "$cd_project_dir/szpaper2/bin/activate" ]]; then
    echo "Environment missing. Run bash setup_ubuntu.sh first." >&2
    return 1
fi
unset PYTHONPATH PYTHONHOME
export PYTHONNOUSERSITE=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
export MPLBACKEND=Agg
export DF_PROJECT_ROOT="$cd_project_dir"
export DF_MODEL_REPO="$cd_project_dir/src/cerebellar-models"
source "$cd_project_dir/szpaper2/bin/activate"
