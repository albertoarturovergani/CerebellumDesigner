"""Verify the delivered source files before installation."""
from pathlib import Path
import hashlib
import json

root = Path(__file__).resolve().parent
manifest = json.loads((root / 'kit_manifest.json').read_text())
for name, expected in manifest['files'].items():
    path = root / name
    if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest() != expected:
        raise SystemExit(f'Package integrity mismatch: {name}')
print(f"Verified {len(manifest['files'])} delivered files.")
