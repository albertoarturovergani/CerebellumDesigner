"""Cached native BSB placement previews; no connectivity or simulation is launched."""
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import fcntl
import json
import os
from pathlib import Path
import subprocess
import sys
import threading

import h5py
import numpy as np
import yaml

from .bsb_adapter import PROJECT, DEFAULT_REPO, guard_hd, prepare, canonical, digest, save
from .core import CORTICAL, LAYER_OF, sample_cells, presence_mask

CACHE = PROJECT / 'DeformationAlgorithm/dashboard/cache/network_placements'
_POOL = ThreadPoolExecutor(max_workers=1, thread_name_prefix='bsb-placement')
_LOCK = threading.Lock()
_ACTIVE = None


def timestamp(): return datetime.now(timezone.utc).isoformat()


def state(key):
    if not isinstance(key,str) or len(key)!=64 or any(c not in '0123456789abcdef' for c in key):
        raise ValueError('Invalid placement key')
    directory=CACHE/key
    if not (directory/'status.json').exists():raise ValueError('Unknown placement preview')
    result=json.loads((directory/'status.json').read_text())
    if result['status']=='COMPLETED':
        result['data']=json.loads((directory/'somas.json').read_text())
    return result


def atomic_status(directory, value):
    temp=directory/'status.tmp';save(temp,value);temp.replace(directory/'status.json')


def request(recipe):
    global _ACTIVE
    guard_hd()
    cfg,geometry=prepare(recipe,CACHE/'pending',DEFAULT_REPO)
    # Include the official placement configuration and structural recipe only.
    recipe={k:v for k,v in recipe.items() if k not in ('electrical','annotations','name')}
    cfg['storage']['root']='network.hdf5'
    key=canonical({'version':2,'recipe':recipe,'configuration':cfg})
    with _LOCK:
        directory=CACHE/key
        if (directory/'status.json').exists():return state(key)
        if _ACTIVE is not None and not _ACTIVE.done():
            raise RuntimeError('A placement preview is already running. Wait for it to finish before generating another.')
        CACHE.mkdir(parents=True,exist_ok=True)
        lock=(CACHE/'worker.lock').open('a+')
        try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError:
            lock.close();raise RuntimeError('A placement worker is already active; no duplicate was started.')
        directory.mkdir()
        cfg['storage']['root']=str(directory/'network.hdf5')
        (directory/'placement.yaml').write_text(yaml.safe_dump(cfg,sort_keys=False))
        (directory/'recipe.yaml').write_text(yaml.safe_dump(recipe,sort_keys=False))
        save(directory/'geometry.json',geometry)
        status={'key':key,'status':'RUNNING','started_utc':timestamp(),'mpi_ranks':8,
                'placement_only':True,'connectivity':False,'simulation':False,'folder':str(directory)}
        atomic_status(directory,status)
        _ACTIVE=_POOL.submit(run,recipe,cfg,geometry,directory,status,lock)
        return status


def extract(recipe,cfg,geometry,path):
    populations={}
    with h5py.File(path,'r') as h:
        if len(h['connectivity']):raise AssertionError('Soma preview must contain no connectivity')
        for pop in cfg['cell_types']:
            group=h['placement'].get(pop)
            chunks=[] if group is None else [group[k]['position'][:] for k in sorted(group,key=int) if 'position' in group[k]]
            xyz=np.concatenate(chunks) if chunks else np.empty((0,3))
            ids=np.arange(len(xyz),dtype=np.int64)
            radii=np.full(len(xyz),geometry['populations'][pop]['baseline_radius_um'],dtype=float)
            keep=np.ones(len(xyz),dtype=bool)
            if pop in CORTICAL:
                values=sample_cells(recipe,pop,ids)
                radii*=1-values[:,2]/100
                keep=presence_mask(recipe,pop,ids,values)
            populations[pop]={'positions':xyz[keep].tolist(),'radii_um':radii[keep].tolist(),
                              'cell_indices':ids[keep].tolist(),'count':int(keep.sum()),
                              'placement_count':len(xyz),'removed_cells':int((~keep).sum()),
                              'layer':LAYER_OF[pop],'has_soma':pop in CORTICAL}
    return {'populations':populations,'network':cfg['network'],'geometry':geometry,
            'source_hdf5':str(path),'source_sha256':digest(path),'recipe_sha256':canonical(recipe),
            'source_kind':'Native BSB placement; per-cell DF removals applied to displayed positions.',
            'coordinate_unit':'µm','all_somas_shown':True,'mpi_ranks':8,
            'connectivity_built':False,'simulated':False}


def run(recipe,cfg,geometry,directory,status,lock):
    try:
        guard_hd()
        env=os.environ.copy();env.pop('PYTHONPATH',None);env.pop('PYTHONHOME',None)
        env.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MPLBACKEND='Agg')
        with (directory/'placement.log').open('w') as log:
            process=subprocess.Popen(['mpirun','-n','8',sys.executable,'-m','cereb_remorph.stage','placement',str(directory/'placement.yaml')],
                 cwd=directory,env=env,stdout=log,stderr=subprocess.STDOUT)
            status['pid']=process.pid;atomic_status(directory,status)
            code=process.wait()
        if code:raise RuntimeError(f'BSB placement exited with code {code}; see {directory / "placement.log"}')
        data=extract(recipe,cfg,geometry,directory/'network.hdf5')
        save(directory/'somas.json',data)
        status.update(status='COMPLETED',finished_utc=timestamp(),hdf5_sha256=data['source_sha256'],
                      somas_sha256=digest(directory/'somas.json'),total_somas=sum(p['count'] for p in data['populations'].values() if p['has_soma']))
    except Exception as exc:
        status.update(status='STOPPED_ON_ERROR',error=str(exc),partial_outputs_preserved=True)
    finally:
        atomic_status(directory,status)
        fcntl.flock(lock,fcntl.LOCK_UN);lock.close()


def reference():
    """Read an existing healthy placement; no new job on slider movement."""
    for directory in sorted(CACHE.iterdir()):
        if not directory.is_dir() or not (directory/'somas.json').exists():continue
        try:
            r=yaml.safe_load((directory/'recipe.yaml').read_text())
            from .core import validate,parameters_for,FEATURES
            r=validate(r)
            if r.get('individuals'):continue
            if any(spec['mean'] or spec['sigma'] for p in CORTICAL for spec in parameters_for(r,p).values()):continue
            if any(v.get(k,0) for group in ('layers','populations') for v in r.get(group,{}).values() for k in ('thickness_df_percent','density_df_percent')):continue
            status=json.loads((directory/'status.json').read_text())
            if status['status']=='COMPLETED':return json.loads((directory/'somas.json').read_text())
        except (ValueError,KeyError,OSError):continue
    raise ValueError('No healthy BSB reference placement is available. Generate a healthy soma preview first.')
