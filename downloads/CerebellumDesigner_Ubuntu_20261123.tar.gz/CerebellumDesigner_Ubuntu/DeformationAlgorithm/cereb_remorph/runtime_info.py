"""Resolve a companion model checkout and report source/runtime versions separately."""
import ast
from pathlib import Path
from importlib.metadata import version, PackageNotFoundError
import subprocess
import sys


def find_model_repo(designer_root, project, override=None):
    if override:
        return Path(override).expanduser().resolve()
    root = Path(designer_root).resolve()
    for candidate in (root, *root.parents, Path(project) / 'src/cerebellar-models'):
        if (candidate / 'configurations/mouse/mouse_cerebellar_cortex.yaml').is_file() and (candidate / 'cerebellar_models/__init__.py').is_file():
            return candidate.resolve()
    # Keep the expected location visible; native_base will report the missing source.
    return (Path(project) / 'src/cerebellar-models').resolve()


def source_version(repo):
    try:
        tree = ast.parse((Path(repo) / 'cerebellar_models/__init__.py').read_text())
        for node in tree.body:
            if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == '__version__' for t in node.targets):
                if isinstance(node.value, ast.Constant) and isinstance(node.value.value, str):
                    return node.value.value
    except (OSError, SyntaxError):
        pass
    return None


def software_versions(repo):
    def installed(name):
        try:
            return version(name)
        except PackageNotFoundError:
            return 'not installed'
    try:
        commit = subprocess.check_output(['git', '-C', str(repo), 'rev-parse', '--short=12', 'HEAD'], text=True, stderr=subprocess.DEVNULL, timeout=2).strip()
        modified = bool(subprocess.check_output(['git', '-C', str(repo), 'status', '--porcelain', '--untracked-files=no'], text=True, stderr=subprocess.DEVNULL, timeout=2).strip())
    except (OSError, subprocess.SubprocessError):
        commit, modified = None, None
    return {'bsb': installed('bsb-core'), 'python_executable': sys.executable,
            'cerebellar_models': source_version(repo), 'cerebellar_models_installed': installed('cerebellar-models'),
            'model_repository': str(Path(repo).resolve()),
            'cerebellar_models_commit': commit, 'cerebellar_models_modified': modified}
