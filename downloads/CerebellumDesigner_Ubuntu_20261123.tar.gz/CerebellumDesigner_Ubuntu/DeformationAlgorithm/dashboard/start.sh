#!/usr/bin/env bash
set -euo pipefail
cd_vm_root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/../.." && pwd)"
exec bash "$cd_vm_root/start_designer.sh" "$@"
