# Ubuntu VM edition — installation entry point

For this delivered package use `ISTRUZIONI_UBUNTU.txt` in the parent folder.
Run `bash setup_ubuntu.sh`, then `bash start_designer.sh` from that parent folder.
This edition uses its own local project directory and `szpaper2` environment;
it does not use the original MyPassport mount policy or paths below.
The following developer documentation is retained for algorithm reference.

# DeformationAlgorithm

BSB 8 cortical deformation with the official in-vitro multireceptor cerebellar model. All local reconstructions and packages remain on the configured HD. Upstream connection rules and source files are preserved. No DCN extension is included.

## Signed changes — public YAML v2

`scale = 1 + change_percent / 100`

- −20% gives ×0.80; zero is the healthy reference; +20% gives ×1.20.
- The dashboard supports −100% to +100% (zero to twice the reference).
- −100% common cell change removes the cell; −100% soma size also removes it. A −100% neurite length or radius retains the soma only.
- −100% density removes that population. −100% layer thickness removes that layer and its populations.
- Sizes, densities and expected counts are different quantities. A 20% linear expansion does not imply 20% volume expansion.
- Electrical changes multiply the signed reference value, including negative voltages. A zero baseline stays zero. Receptor IDs are fixed; electrical and geometric validity checks still apply.

```yaml
schema: cereb-df/v2
name: Example signed cortical changes
seed: 1234
defaults:
  df_percent: {mean: 0, sigma: 0, bounds: [-100, 100]}
layers:
  granular_layer:
    thickness_df_percent: -10
    density_df_percent: 20
populations:
  golgi_cell:
    cells:
      neurite_length_df_percent: {mean: -20, sigma: 0}
      neurite_radius_df_percent: {mean: 20, sigma: 0}
      soma_size_df_percent: {mean: 0, sigma: 0}
      rotation_x_deg: {mean: 180, sigma: 0}
individuals: []
```

The editor deliberately offers **uniform effects only**, with one `Change %` or angle and no sigma controls. The serialized cell schema retains `mean` and `sigma: 0` for compatibility with the algorithm. Importing a heterogeneous recipe into the editor explicitly resets its sigmas to zero and displays a notice; the source file is not modified. Direct code/CLI use still supports heterogeneous cell distributions.

Network thickness and density are **scalar, deterministic** values. Legacy `{mean: ..., sigma: 0}` network values import losslessly as scalars. A nonzero network sigma is rejected by the engine; the simplified editor resets dispersion during import with a notice.

### Legacy compatibility

Existing `cereb-df/v1` files continue to mean inverse DF: positive 20% is a reduction. `recipe_format.py` converts between v1 and signed v2 by reflecting DF means/bounds and electrical percentages, preserving sigma and rotation angles. The internal engine retains its inverse convention so keyed samples from old recipes are unchanged. All newly exported recipes and reports use v2. Never relabel a v1 file as v2 without converting its numbers.

Cell rule precedence is defaults → layer → population → individual. A common DF shares one draw between size features; explicit features override it. Rotations are extrinsic X, then Y, then Z, in degrees about the root soma. Native SWC labels and axes are retained. General cell-only distributions use bounded beta arithmetic moments; angles use normal distributions. There is no silent clipping. Soma placement reserves the maximum allowed radius.

## Dashboard

Run `bash dashboard/start.sh`, then open `http://127.0.0.1:8891/`.

- Healthy zero settings on startup; Reset cell and Reset all remain available.
- Cells and Network each have Morphological / Electrical modes.
- **Overall change** writes the same absolute percentage into all size details (or all network thickness/density values). Details are always editable. Editing any detail returns the Overall command to zero and preserves the other values; it does not apply a second scale factor. Rotations remain independent. A new Overall value replaces the affected detail values, including population density overrides. Electrical parameters remain individually editable.
- Network scatter and layer geometry appear side by side, with thickness/density controls underneath.
- Live scatter is an **estimate** based on a healthy native BSB placement. Layer coordinates, density thinning/expansion and uniform soma radii update immediately; added points are synthetic. It is not a collision-checked reconstruction. **Verify BSB placement** computes actual somata/counts with MPI ×8. Neither preview mode constructs synapses or runs a simulation.
- SZ preload is a versioned **literature-guided hypothesis**, not a calibrated disease model. Notes distinguish human measurements, derived conversions and chosen strengths. Alzheimer, autism and ataxia are placeholders, disabled until defined.
- The single built-in **SZ — structure + NMDA**, preset revision 2.0, uses primary-study citations in each parameter note (Maloku 2010, Andersen & Pakkenberg 2003, Mavroudis 2017, Tran 1998, Schmitt 2010, Bullock 2009). PC planar density is −20%: the relative human linear-density deficit from Maloku is transferred to mouse planar density as an explicit modelling assumption; actual counts depend on placement. PC neurite length is −15%, soma linear size −4.24%, and both molecular-layer thicknesses −10%. PC neurite radius is unchanged. Only NMDA weights change: glomerulus→granule −20%, glomerulus→Golgi and ascending axon→Golgi −15%, relative to each compatible TM/static baseline. GABA, AMPA, intrinsic constants, kinetics, delays and TM dynamics remain canonical. The granular/Purkinje layers remain 130/15 µm; total cortical depth becomes 280 µm. Thickness notes now include Andersen Table 4's regional measurements and nonsignificant results, which do not calibrate the exploratory −10%. Notes distinguish measured effects, derived conversions and chosen magnitudes. Historical profiles and run recipes are not migrated.
- Notes remain empty for healthy/custom profiles. Preload fills linked evidence and references; manual notes are optional. Changing a referenced parameter marks that evidence group as modified. Internal Drive copies are identified as copies, not independent evidence.
- Review & save exports a portable ZIP with v2 recipe, pretransformed SWCs, native structural YAML with relative paths, compatible TM/static multireceptor fragments, HTML/PDF reports, hashes and a standalone MPI-8 launcher. The final panel contains the copyable Bash command.

## Reconstruction

```bash
source /media/alberto/MyPassportAlbertoColoreROSSO/SZ_PAPER2/attiva_szpaper2.sh
cereb-df validate /absolute/path/deformation_profile.yaml
cereb-df build /absolute/path/deformation_profile.yaml --output /absolute/path/on/HD/new_network
```

Use the exported `reconstruct.sh` for pinned package/environment checks. Portable exports bake uniform morphology changes into SWCs before reconstruction. The launcher places with `mpirun -n 8`, annotates cell assignments, then computes native connectivity with `mpirun -n 8`. It does not apply deformation again. Use the launcher instead of compiling `structural.yaml` directly so absent-feature handling and validation are retained. The direct `cereb-df build` CLI continues to support the original staged per-cell transformation workflow. Existing output folders are never overwritten. Placement checkpoints and partial failures are preserved. Cell removal filters eligible connectivity targets; native rules still determine actual contacts. Electrical YAML is a fragment for a later simulation; no stimulation protocol is selected here.

## Validation

`python -m unittest discover -s tests -p 'test_*.py'` checks transformations, historical parity, signed v2 effects, endpoints, geometry, all five populations, TM/static receptors, annotations, origin restrictions and exports. `node tests/test_live_network.cjs` checks live estimates independently. Small MPI fixtures validate the staged builder without scientific simulations. Finite native counts can differ from density expectations because of placement/chunk allocation.


## Designer v0.0.1

Maintained by Alberto Arturo Vergani. Percentage edits are relative to the native healthy reference: -20% means x0.80, +20% means x1.20. Morphological expansion preserves branch topology; it does not generate branches or spines. DCI uses Masoli et al. (2024), equation 2, https://doi.org/10.1038/s42003-023-05689-y: (sum of terminal branch orders + number of tips) * total dendritic length / primary dendrites. Orders count dendritic branch points, with primary stem order 0; SWC interpolation does not increase order. Lengths are in micrometres, and DCI inherits that length unit. No dendrites gives zero by convention.

Morphology/network details are always visible and editable; Overall is a write-to-all command, not an additional factor. A freshly loaded profile displays Overall at zero and retains its individual settings. Electrical parameters are always individual. Raw reference/current values, units and concise definitions accompany percentage sliders.

Instant network preview is a proportional estimate from healthy positions. Volumetric populations scale with density and thickness; PC density is per area. Expansion may generate synthetic preview points. Verify BSB placement runs actual placement (no connectivity or simulation).

Save profile writes an immutable YAML revision in presets; saved revisions reappear in the preload list after reopening. Parameter notes are stored in annotations.parameter_notes and collected by parameter path in the dashboard and HTML/PDF report. General notes remain separate.

Review & save always shows terminal instructions. Save YAML & package saves a configuration package and generates its exact Bash command. It does not launch reconstruction; the user runs the copied command. Changes invalidate a previously generated command. The reconstruction launcher uses MPI x8 and protects existing outputs.


## Model repository, runtime and seed

Cerebellum Designer is a companion application, not an upstream BSB plugin. It can be kept in a subfolder of a cerebellar-models checkout: the closest enclosing checkout with the native cortical configuration and Python package is detected. `DF_MODEL_REPO` overrides detection; the configured project’s `src/cerebellar-models` is the fallback. The source version and Git revision are read from that selected checkout. BSB and the installed model-package version come from the active Python environment; putting folders together does not install or update dependencies. This local deployment still uses `local_storage.json`, the HD guard, the `szpaper2` environment and its activation script. Relocation requires configuring those paths and the environment; it is not a self-contained portable installation.

The single reconstruction seed is shared across the configuration. BSB uses it for stochastic reconstruction; uniform geometry changes do not depend on it. Same-seed configurations with different geometry are not guaranteed to have identical topology or one-to-one cell correspondence. The editor does not configure a NEST spike-generation seed.

## Spatial sampling limitation

In the current cortical checkout, 12 `VoxelIntersection` pathways use `voxels_pre = voxels_post = 500`. These values set an approximate subdivision count for each morphology bounding box, not a fixed micrometre pitch. BSB 8.0.2 `VoxelSet.from_morphology` assigns branch sample points to voxels; that operation neither interpolates inter-point segments nor expands occupancy using neurite radii. A radius-only change therefore does not directly change occupancy for this strategy. Morphology deformation changes the physical voxel size. The 100 × 100 × 100 µm network chunk setting is a separate placement/storage/task partition, not a morphology discretization setting. Before altering resolution policy, test contact counts and convergence/divergence against voxel counts and SWC sample spacing. No such convergence sweep or automatic adjustment is performed by this UI update.

Save to profile list creates a reusable recipe revision. Save YAML & package creates a new export directory and the copyable command; Save & download ZIP additionally downloads the archive. Neither action starts a reconstruction. Electrical files are simulation-model fragments without stimuli; the network HDF5 is produced only by running the exported launcher.

Orientation / tilt is always visible in Cells → Morphological, including Overall mode. X, Y and Z are fixed network axes; rigid rotations are applied around the soma in that order, baked once into SWC coordinates before connectivity, and exported in the recipe. Camera dragging changes the view only. Uniform rotation preserves branch lengths, radii and DCI; it can affect morphology-dependent contacts when reconstructing.

Electrical selectors follow model → condition → compatible synapse preset, synchronised between Cells and Network. The backend derives available TM/static variants from the selected supported source and rejects incompatible recipes. The NEURON placeholder is disabled and exposes no NEST presets. Export includes only variants compatible with that model/condition; adding a simulator requires its own source, compilation and validation support.

### Dendritic bifurcation tilt (exploratory)

`cells.bifurcation_tilt_deg: {mean: -10, sigma: 0}` adds an angle change in
**degrees**, independently of length/radius effects and whole-cell XYZ rotation.
Default zero is an exact identity; existing profiles and the SZ preset are unchanged.
See `examples/purkinje_bifurcation_tilt.yaml` for a canonical Purkinje demonstration.

At each binary dendritic fork, the algorithm rotates each daughter subtree about
its junction, proximal to distal. Its parent-facing local angle receives the
requested signed change and is clipped to 1–179°. Duplicate junction samples are
retained: direction uses the nearest noncoincident sample on the unbranched arm.
Nonbinary forks, mixed axonal subtrees and unresolved zero-length directions are
excluded and counted. The current version requires sigma=0 for this parameter.

Lengths, radii, SWC identifiers, parent links, soma, axon and DCI are preserved by
tilt alone. Spatial extent, branch opening angles and potential synaptic contacts
can change; no collision avoidance or layer clipping is imposed. Native BSB
connectivity is recomputed after the geometry is transformed. This changes no
intrinsic electrical parameter and does not model dendritic voltage propagation
in the EGLIF point-neuron model.

The dashboard provides a linked **Before / after** view, local and remote tilt
statistics and clipping counts. Local tilt is the minimum angle between the
parent-facing segment and the two daughter directions. Remote tilt uses the
previous/next branch endpoints and is measured, not independently targeted.
The YAML, reconstruction metadata, HTML/PDF reports and package hash checks include
the new operator. `cell_assignments.json` records per-morphology tilt audits.

Biological motivation: [Mavroudis et al. (2017), Figure 1D](https://rjme.ro/RJME/resources/files/580217419424.pdf).
The demonstrated -10° is **not** extracted from that figure or calibrated to
human schizophrenia. This explicit operational convention has not been validated
against the authors' original tracing pipeline; angle magnitudes must not be
compared as if the pipelines were identical.

## Portable export — 23 November 2026

The downloaded ZIP can be extracted into another directory or machine with the matching BSB 8 / MPI / cerebellar-models environment. Run:

```bash
bash reconstruct.sh --check
bash reconstruct.sh
```

The launcher also accepts `--output /path/to/a/new_folder`. Set `CD_PYTHON=/path/to/venv/bin/python` when the intended interpreter is not on PATH. It never activates a hard-coded HD environment and never installs software or runs a simulation. Both reconstruction stages use exactly eight MPI processes; existing output directories are refused and partial output is preserved on errors. The GUI command selects the local interpreter for convenience; README.txt contains portable instructions.

All five cortical morphology templates are included, with source axis conversion and deformation applied once. Native names and parser labels are preserved. Uniform transformations are supported, including soma-only and absent populations. Zero-count populations keep an uninstantiated reference template so the native importer can resolve their morphology. Heterogeneity or explicit individual overrides are rejected by this export; use the existing staged CLI for those recipes.

The standalone runner checks package hashes, exact package versions and the installed cerebellar-models scientific code fingerprints. Original source paths in manifest provenance are historical information only and are not read at reconstruction time. The app itself still uses its configured HD paths; this change makes exported reconstruction packages portable, not the entire Designer installation.
