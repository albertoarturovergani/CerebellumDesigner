"""No simulation: each MPI process confirms its rank and communicator size."""
from mpi4py import MPI

comm = MPI.COMM_WORLD
assert comm.Get_size() == 8, f'Expected 8 processes, got {comm.Get_size()}'
print(f'MPI rank {comm.Get_rank()} of {comm.Get_size()}', flush=True)
