"""Check the relocated Designer; this does not reconstruct or simulate a network."""
from importlib.metadata import version
from pathlib import Path
import json
import os
import subprocess
import sys

root = Path(__file__).resolve().parent
assert sys.version_info[:2] == (3, 12), 'This kit is validated with Python 3.12.'
for package, expected in {
    'bsb': '8.0.2', 'bsb-core': '8.0.2', 'bsb-hdf5': '8.0.2',
    'bsb-json': '8.0.2', 'bsb-yaml': '8.0.2', 'cerebellar-models': '0.13.0',
    'bsb-native': '8.0.2', 'bsb-otel': '8.0.2',
    'numpy': '2.5.4', 'scipy': '1.18.1', 'h5py': '3.16.0', 'mpi4py': '4.1.2',
}.items():
    found = version(package)
    assert found == expected, f'{package}: expected {expected}, found {found}'
    print(f'{package}: {found}')
import reportlab
import cereb_remorph
import cerebellar_models
from bsb import Scaffold
from cereb_remorph.designer import catalog, morphology_payload
from cereb_remorph.bsb_adapter import guard_hd
assert Path(cereb_remorph.__file__).resolve().is_relative_to(root / 'DeformationAlgorithm')
assert Path(cerebellar_models.__file__).resolve().is_relative_to(root / 'src/cerebellar-models')
guard_hd()
data = catalog()
assert len(data['populations']) == 7
assert data['electrical']['model'] == 'eglif_multirec'
morphology_payload('purkinje_cell')
print('Designer catalog, cortical morphologies and electrical presets: OK')
print('No reconstruction or simulation started.')
