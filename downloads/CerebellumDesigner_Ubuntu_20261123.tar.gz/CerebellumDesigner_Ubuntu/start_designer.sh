#!/usr/bin/env bash
set -euo pipefail
cd_launcher_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
source "$cd_launcher_dir/activate.sh"
cd "$cd_launcher_dir"
echo "Open http://127.0.0.1:${1:-8891}/ in the browser INSIDE Ubuntu. Ctrl+C stops Designer."
exec python -m cereb_remorph.designer --port "${1:-8891}"
